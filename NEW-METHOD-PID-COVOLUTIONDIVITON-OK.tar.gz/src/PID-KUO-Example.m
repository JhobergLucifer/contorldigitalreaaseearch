# Control PID KUO 8th Automatic Control Systems 9-32
# by Jhoberg Quevedo Ruiz
# Engineer


%           u    +         +---+      +------+y
%          ------>(+)----->| Gs |----->| Gp |--------+------->
%                  ^ -     +---+      +------+       |
%                  |                                 |
%                  +---------------------------------+


pkg load symbolic;
pkg load control;

syms S
syms Kp
syms Kd
syms Ki
syms E
syms wn

%%%%%%%%%%%Transfer Fuction Plant 
Gp=0.00667/(S*S+0.00667)
%control PID
Gc=Kp+S*Kd+Ki/S
Gol=Gc*Gp
Gcl=Gol/(1+Gol)

[numGp, denGp] = numden(sym(Gp))
den=double(coeffs(denGp))
%den=sym2poly(denGp,S)
%error captuado coeficientes constantes numerador
%num=sym2poly(numGs)
num=40;
den=[5997 0 40]
GP=tf(num,den)
step(GP);
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

step(feedback(GP))
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");


%%%%%%%%%%%%%%%%Control PID



%error state stable rampa unitaria <=0,000433
%sobrepaso max<=5%
%tiempo levantamiento tr<=0,005 seg
%tiempo asentamiento ts <=0,005 seg


Gcl=simplify(Gcl)
Gcl=partfrac(Gcl)
[numGcl, denGcl] = numden(sym(Gcl))
dencl=sym2poly(denGcl,S)
%denfb=disp(denfb)
numcl=sym2poly(numGcl,S)
%numfb=disp(numfb)


%calculo PID controller
%1) error estado estable ess
%Ke=limS-Z0 Gol(S), entrada escalon unitario
Ke=0.00667*Ki/0.00667;
ess=1/(1*Ki)
solve(0.001==1/(1+Ki),Ki)
%Kp=100

%%%%%%%%
%2)caculo Overshot sistema 2nd order 
solve(0.02==exp(-pi*E/(1-E*E)^0.5),E)
E=0.707;
%%%%%
%3) calculo Tiempo retardo tr 
% aproxlinea recta 
tr=(0.8+2.5*E)/(wn)
wn=solve(2.5==(0.8+2.5*E)/wn,wn)
wn=1;

%caculo Ecuacion caracteristica close loop Gcl , 
%ecuacion caracteristica orden 2
% division de ec Gcl enre ecacion caracteristica ideal odern 2
%usando fucion division convulucion polinomios

[q,r,qc,rc]=divideconv([1 0.00667*Kd 0.00667*(1+Kp) 0.00667*Ki],[1 1.414 1],1)

%resultado polinomio sedespeuja2 ecuaciones
Ki=100
Kd=312
Kp=290.18


%controllador Gc=Kp+S*Kd+Ki/S=(S*S*Kd+S*Kp+Ki)/(S)
GC=tf([Kd Kp Ki],[1 0])

Gol1=tf([2.08 1.9355 0.667],[1 0 0.00667 0])
step(feedback(Gol1),'m')

title ("PD Control Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

hold off
step(feedback(GP*GC),'g')




