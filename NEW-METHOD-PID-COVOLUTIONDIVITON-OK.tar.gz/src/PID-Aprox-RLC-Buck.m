%Jhoberg Quevedo
%Engieer
%PID aproximacion optimization 
%Controlador K*(S+a)²/S, K*S+2*K*a+K*a²/S
%Gp=6000000/(6*S²+125*S+6000000)
%Desing PID whit Computational Optimization APPROACH

pkg load symbolic;
pkg load control;


%K and values a
K=[86 88 90 92 94 96 98 100 102 104 106 108 110 102 104]
a=[0.1 0.5 1.0 1.5 2.0 0.1 0.5 1.0 1.5 2.0 2.5 3.0]

%Evaluate Close-Lopp unit-steep responce at each "K" and "a" combination
%that woll yeild the maximum oversoot less that 10%

   t=0:0.01:0.5
   g=tf([6000000],[6 125 6000000])
   k=0
   for i=1:12
	   for j=1:12
		   gc=tf(K(i)*[1 2*a(j) a(j)*a(j)],[1 0]); %controller 
       G=gc*g/(1+gc*g); % closed loop transfer
		     y=step(G,t)
		     m=max(y);
         
         if m<1.4
		                k=k+1
                    solution(k,:)=[K(i) a(j) m]
                    
         end
		 end
   end
   solution % print soluction
		     
	 sortsolution=sortrows(solution,3)

 % Plot the response with the largets overshot that is less than 10%
           
           
           
          %overshot 0%
           K=sortsolution(11,1)
           a=sortsolution(11,2)
           gc=tf(K*[1 2*a a*a],[1 0])
           G=gc*g/(1+gc*g);
           step(G,t)
           grid   
 
		       K=sortsolution(k,1)
		       a=sortsolution(k,2)
		       gc=tf(K*[1 2*a a*a],[1 0])
		       G=gc*g/(1+gc*g)
		       step(G,t)
		       grid
		       K=sortsolution(11,1);
		       a=sortsolution(11,2);
		       gc=tf(K*[1 2*a a*a],[1 0]);
		       G=gc*g/(1+gc*g);
		       step(G,t);
		       grid,
		       
          
          
       