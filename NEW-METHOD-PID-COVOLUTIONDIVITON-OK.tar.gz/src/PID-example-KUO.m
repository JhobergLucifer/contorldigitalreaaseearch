# PD Example 10-1 book Modern Control Engineering 3ed Ogata
# by Jhoberg Quevedo Ruiz
# Engineer


%           u    +         +---+      +------+y
%          ------>(+)----->| Gs |----->| Gp |--------+------->
%                  ^ -     +---+      +------+       |
%                  |                                 |
%                  +---------------------------------+

pkg load symbolic;
pkg load control;

syms S
syms Kp
syms Kd
syms Ki

%overshot 25%
%max overshot 40%
%tuning max overshot 25%

%trasfer fuction plant

Gp=1/(S*(S+1)*(S+5))

%tranfer function Controller PID

Gc=Kp*(1+1/(Ki*S)+Kd*S)

Gol=Gp*Gc
Gcl=Gol/(1+Gol)
Gcl=partfrac(Gcl)
%method Ziegler-Nichols tendeindo Ki=infinito, Kd=0
%Tf close-loop remake
Gc1=Kp;
Gol1=Gc1*Gp
Gcl1=Gc1*Gp/(1+Gc1*Gp)
Gcl1=partfrac(Gcl1)
Gclpoly=[1 6 5 Kp]
