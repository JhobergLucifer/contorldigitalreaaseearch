% PID en Tiempo Orden 2
% Jhoberg Quevedo
% Engineer
pkg load symbolic;
pkg load control;

syms S
syms t
syms wn
syms E

%G(S)=Y(S)/E(S)=wn^2/(S*(S+2*E*wn))
%ecucacion Lazo Cerrado GCL
%Gp=wn^2/(S*(S+2*E*wn))
Gp=wn*wn/(S*(S+2*E*wn))
%entrada escalon unitaria
YS=wn*wn/(S*(S*S+S*2*E*wn+wn*wn))

ft = rewrite(ilaplace(YS), 'Integral')
