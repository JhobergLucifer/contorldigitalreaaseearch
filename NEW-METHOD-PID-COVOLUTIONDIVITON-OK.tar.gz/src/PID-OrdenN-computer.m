%ejemplo 8-2 libro Modern-Control-Engieering 5th Ogata
%Controlador K*(S+a)²/S
%Gp=1.2/(0.36S³+1.86*S²+2.5*S+1)
%Desing PID whit Computational Optimization APPROACH


%K and values a
K=[2.0 2.2 2.4 2.6 2.8 3.0]
a=[0.5 0.7 0.9 1.1 1.3 1.5]

%Evaluate Close-Lopp unit-steep responce at each "K" and "a" combination
%that woll yeild the maximum oversoot less that 10%

   t=0:0.1:5
   g=tf([1.2],[0.36 1.86 2.5 1])
   k=0
   for i=1:6
	   for j=1:6
		   gc=tf(K(i)*[1 2*a(j) a(j)*a(j)],[1 0]); %controller 
       G=gc*g/(1+gc*g); % closed loop transfer
		     y=step(G,t)
		     m=max(y);
         
         if m<1.10
		                k=k+1
                    solution(k,:)=[K(i) a(j) m]
                    
         end
		 end
   end
   solution % print soluction
		     
	 sortsolution=sortrows(solution,3)

 % Plot the response with the largets overshot that is less than 10%
    
           %overshot 0%
           K=sortsolution(11,1)
           a=sortsolution(11,2)
           gc=tf(K*[1 2*a a*a],[1 0])
           G=gc*g/(1+gc*g);
           step(G,t)
           grid  
 %plot overshot 10%
		       K=sortsolution(k,1)
		       a=sortsolution(k,2)
		       gc=tf(K*[1 2*a a*a],[1 0])
		       G=gc*g/(1+gc*g)
		       step(G,t)
		       grid
		       K=sortsolution(11,1)
		       a=sortsolution(11,2)
		       gc=tf(K*[1 2*a a*a],[1 0])
		       G=gc*g/(1+gc*g)
		       step(G,t)
		       grid
		     
          
       