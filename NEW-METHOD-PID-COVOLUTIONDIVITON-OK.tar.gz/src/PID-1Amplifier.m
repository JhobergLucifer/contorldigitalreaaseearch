# Control PID Circuit 1 Amplifier
# by Jhoberg Quevedo Ruiz
# Engineer


pkg load symbolic;
pkg load control;

syms S
syms Kp
syms Kd
syms Ki
syms R1
syms C1
syms R2
syms C2
syms i1
syms i2
syms i3
syms Vi
syms Vo


%vref=0
i1=(Vi-0)/R1
i2=(0-Vo)/(1/(S*C1)+R2)
i2=partfrac(simplify(i2))
i3=(0-Vo)/(1/(S*C2))

%i1==i2+i3
i1==i2+i3
#Vo/Vi=G(S)
a1=i2+i3

G=-(S*C1*R2+1)/(R1*(S*S*C1*C2*R2+S*(C1+C2)))
G=partfrac(simplify(G))

step(feedback(G))

