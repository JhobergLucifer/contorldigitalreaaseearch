# Control PID Circuit Buck RLC
# by Jhoberg Quevedo Ruiz
# Engineer


%           u    +         +---+      +------+y
%          ------>(+)----->| Gs |----->| Gp |--------+------->
%                  ^ -     +---+      +------+       |
%                  |                                 |
%                  +---------------------------------+


pkg load symbolic;
pkg load control;

syms S
syms Kp
syms Kd
syms Ki
syms C
syms L
syms RL
syms E
syms wn
%%%%%%%%%%%Transfer Fuction Plant Circuit RLC
%K=181.17
Vi=120
%Gp=(4500*K)/(S*(S+361.2))


z1=(1/((1/(1/(S*C)))+1/RL))
Vo=Vi*(z1)/(z1+S*L)
Vo=simplify(Vo)
%tranfer function Gs=Vo/Vi
%ver impresion Gs, funcion sym2poly no abstre en pow 0

Gp=z1/(z1+S*L)
Gp=simplify(Gp)

RL=48;
C=1000E-6;
L=10E-3;

[numGp, denGp] = numden(sym(Gp))
den=double(coeffs(denGp))
%den=sym2poly(denGp,S)
%error captuado coeficientes constantes numerador
%num=sym2poly(numGs)
num=6000000;

GP=tf(num,den)
step(GP);
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

step(feedback(GP))
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");


%%%%%%%%%%%%%%%%Control PID



%error state stable rampa unitaria <=0,000433
%sobrepaso max<=5%
%tiempo levantamiento tr<=0,005 seg
%tiempo asentamiento ts <=0,005 seg

%controlador PID
Gc=Kp+Kd*S+Ki/S


G=Gp*Gc
G=simplify(G)
Gcl=G/(1+G)
Gcl=simplify(Gcl)
Gcl=partfrac(Gcl)
[numGcl, denGcl] = numden(sym(Gcl))
dencl=sym2poly(denGcl,S)
%denfb=disp(denfb)
numcl=sym2poly(numGcl,S)
%numfb=disp(numfb)
dencl1=[6 6000000*Kd+125 6000000*Kp+6000000 6000000*Ki]
numcl1=[6000000*Kd 6000000*Kp 6000000*Ki]
%GCL=tf(numcl1,dencl1)

%calculo PID controller
%1) error estado estable ess
%Ke=limS-Z0 Gol(S), entrada escalon unitario
Ke=6000000*Ki/6000000;
ess=1/(1+Ki)
solve(0.001==1/(1+Ki),Ki)
%Kp=100

%%%%%%%%
%2)caculo Overshot sistema 2nd order 
solve(0.01==exp(-pi*E/(1-E*E)^0.5),E)
E=0.843892;
%%%%%
%3) calculo Tiempo retardo tr 
% aproxlinea recta , fr=1/(L*C)^0.5=316.22 , tr>>10*1/fr  
tr=(0.8+2.5*E)/(wn)
wn=solve(0.0003==(0.8+2.5*E)/wn,wn)
%wn=97000;

%4)caculo PID , ecuacion caracteristica Close Loop Gcl
%divisor orden 2 , S*S+2*E+wn+wn*wn
%numerador Gcl [6*S*S+S*(6000000*Kd+125)+S(6000000*Kp+6000000)+6000000*Ki]
%S*S+S*(1000000*Kd+20.833)+1000000
eccden=[1 2*E*wn wn*wn]
eccnum=[6 6000000*Kd+125 6000000*Kp+6000000 6000000*Ki]
[q,r,qc,rc]=divideconv(eccnum,eccden,1)

%resultado polinomio sedespeuja2 ecuaciones
Ki=100
Kd=0.016350
Kp=93

%controllador Gc=Kp+S*Kd+Ki/S=(S*S*Kd+S*Kp+Ki)/(S)
GC=tf([Kd Kp Ki],[1 0])
step(feedback(GP*GC))

title ("PD Control Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");


%calculo aprox PID circuit 
%Kp=-(Rfb/Rp), Rfp=100K, Rp=1000
Kp=100
%Ki=-1/(S*Cd*Rd), Cd=104pF, Rd=100K
Ki=100
%Kd=-S*Ci*Ri, Ci=104Pf, Ri=160K, Ri=150K
Kd=0.015
hold on 
GC=tf([Kd Kp Ki],[1 0])
step(feedback(GP*GC),'m')

hold off




