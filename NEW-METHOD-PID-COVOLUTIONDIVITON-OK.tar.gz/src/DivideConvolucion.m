%Jhoberg 
%Engineer
%Division Polinomio Convolucion

function  outconv=divconv(nump,denp);

xi=0 
topcv=0 
hi=0;
top1=size(nump);
top1=top1(2);
top2=size(denp);
top2=top2(2);
printf("top1 %d ,top2 %d \n",top1,top2);
 for xi=top1-1:xi>=0:xi-- 
      topcv=(top1-1)-xi;
    for hi=top2-1:hi>=0:hi--
        outconv(topcv)=(convrs(topcv)+x(xi)*h(hi))
	      printf("yn:[%d]%d #xn:[%d]%d #hn:[%d]%d \n",topcv,convrs(topcv),xi,xn(xi),hi,hn(hi));
	     topcv++
      end
   end 
   outconv
 end 

