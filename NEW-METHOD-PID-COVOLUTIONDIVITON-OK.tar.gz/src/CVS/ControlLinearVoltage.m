%#Control PID Circuit Linear Voltage Regulator 7805 AND REFFERECIAS
%de corriente y voltage
%#By Jhoberg Engineer 2019

% u    +         +--------+             y
%------>(+)----->| sys1  |-------+------->
%        ^ -     +--------+      |
%        |                       |
%        |      +--------+       |
%        +-------| sys2  |<------+
%               +--------+

%calculo H(s) funcion transferencia




pkg load symbolic;
pkg load control;

syms S;


%RL=50;
C=100E-6;
R=48;
L=10E-3;
Vi=18;
Vo=5;

RL=S*L+((R*1/(S*C))/(R+(1/(S*C))));
%RLl=simplify(RL)
%Hs=Vo/Vo

Hs=Vo/(Vi*RL);
HS=simplify(Hs)			    			    

%partif coeficientes polinomio Hs
			    
[numHs, denHs] = numden(simplify(HS));
den=sym2poly(denHs);
num=sym2poly(numHs);

HsTf=tf(num,den)
step(HsTf);
title ("Step Linear Regulator Voltage");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

%Control PID
