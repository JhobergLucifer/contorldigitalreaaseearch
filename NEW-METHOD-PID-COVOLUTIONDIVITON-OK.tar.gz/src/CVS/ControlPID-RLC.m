%#Control PID Circuito RLC PWM BUCK
%#By Jhoberg Engineer 2019

%           u    +         +---+      +------+y
%          ------>(+)----->| Gs |----->| Hs |--------+------->
%                  ^ -     +---+      +------+       |
%                  |                                 |
%                  +---------------------------------+


pkg load symbolic;
pkg load control;

syms S;

%Circuitto RLC Buck

C=100E-6;
RL=48;
L=10E-3;
Vi=1;
Vo=1;

  
Num1=Vi*((1/(S*C))*RL)
Den1=1/(S*C)+RL
Num=Num1/Den1;
Den=(S*L)+((RL*1/(S*C))/(1/(S*C)+RL))
Hs=Num/Den;
HS=simplify(Hs)

%ver impresion Gs, funcion sym2poly no abstre en pow 0

[numHs, denHs] = numden(sym(HS));
den=sym2poly(denHs);
%num=sym2poly(numHs);
num=11000000;
HsTf=tf(num,den)
step(HsTf);
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

%Control PID






  
