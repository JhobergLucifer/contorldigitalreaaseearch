# Circuto Buck RLC 
# by Jhoberg Quevedo Ruiz
# Engineer


pkg load symbolic;
pkg load control;

syms S;
%syms RL,C,L,Vi,Vo;

z1=(1/((1/(1/(S*C)))+1/RL))
Vo=Vi*(z1)/(z1+S*L)
Vo=simplify(Vo)
%tranfer function Gs=Vo/Vi
%ver impresion Gs, funcion sym2poly no abstre en pow 0

Gs=z1/(z1+S*L)
Gs=simplify(Gs)

RL=48;
C=1000E-6;
L=10E-6;

[numGs, denGs] = numden(sym(Gs))
den=sym2poly(denGs)
%error captuado coeficientes constantes numerador
%num=sym2poly(numGs)
num=600000000;

GS=tf(num,den)
step(GS);
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

