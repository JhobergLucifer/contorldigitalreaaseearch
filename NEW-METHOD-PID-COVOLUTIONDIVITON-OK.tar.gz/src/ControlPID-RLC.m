%#Control PID Circuito RLC PWM BUCK
%#By Jhoberg Engineer 2019

%           u    +         +---+      +------+y
%          ------>(+)----->| Gs |----->| Hs |--------+------->
%                  ^ -     +---+      +------+       |
%                  |                                 |
%                  +---------------------------------+


pkg load symbolic;
pkg load control;

syms S;

%Circuitto RLC Buck

C=1000E-6;
RL=48;
L=10E-3;
Vi=120;



z1=(1/((1/(1/(S*C)))+1/RL))
Vo=Vi*(z1)/(z1+S*L)
Gp=z1/(z1+S*L)
%Gp Vo/Vi

Gp=simplify(Gp)
Gp=partfrac(Gp)
%ver impresion Gs, funcion sym2poly no abstre en pow 0

[numGp, denGp] = numden(sym(Gp));
den=sym2poly(denGp);
%error coeficnte ordern zero 
%num=sym2poly(numGp);
num=6000000
GpTf=tf(num,den)
step(GpTf);
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

%Graficas Hs en bode y RootLocust
%pole(HsTf)
%rlocus(HsTf)
%bode (HsTf)

%Grafica feedback sin controlador
step(feedback(GpTf))

%controlador PID 2 Amplificadores 
%Gc=Kp(1+1/(Ki*S)+Kd*S)
%Gc=tf([3 12 12],[1])
% PID K*S+2*K*a+K*a²/S
K=100;
a=15;
Gc=tf([K 2*K*a a*a*K],[1] )

Gol=Gc*GpTf/(1+Gc*GpTf)
step(Gol)


  
