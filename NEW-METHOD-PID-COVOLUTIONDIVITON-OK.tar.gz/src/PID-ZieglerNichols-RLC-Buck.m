%#Control PID Circuito RLC PWM BUCK
%#By Jhoberg Engineer 2019

%           u    +         +---+      +------+y
%          ------>(+)----->| Gs |----->| Hs |--------+------->
%                  ^ -     +---+      +------+       |
%                  |                                 |
%                  +---------------------------------+


pkg load symbolic;
pkg load control;

syms S;
syms EPS;
syms Kp;
%Circuitto RLC Buck

C=1000E-6;
RL=48;
L=1E-3;
Vi=120;



z1=(1/((1/(1/(S*C)))+1/RL))
Vo=Vi*(z1)/(z1+S*L)
Gp=z1/(z1+S*L)
%Gp Vo/Vi

Gp=simplify(Gp)
Gp=partfrac(Gp)
%ver impresion Gs, funcion sym2poly no abstre en pow 0

[numGp, denGp] = numden(sym(Gp));
den=sym2poly(denGp);
%error coeficnte ordern zero 
%num=sym2poly(numGp);
num=6000000
GpTf=tf(num,den)
step(GpTf);
title ("Step RLC Buck");
xlabel ("Time");
ylabel ("Voltage");
%text (pi, 0.7, "arbitrary text");
legend ("Signal Voltage Vo");

%Control PID Ziegler-Nichols aprox Kd->0 Ki->infinito
%Y(S)/R(S)=Gcl wihhit feeedback 1

Gcl=(Gp*Kp)/(1+(Gp*Kp))
Gcl=partfrac(Gcl)
[numGcl, denGcl] = numden(Gcl);
dencl=double(coeffs(denGcl))
numcl=double(coeffs(numGcl))

dencl=[6 125 (6000000*(1+Kp))]
%Rputh Roots
routh(dencl,EPS)

%Grafica feedback sin controlador
step(feedback(GpTf))


%controlador PID 2 Amplificadores 
Gc=Kp(1+1/(Ki*S)+Kd*S)


