# PID 2 Amplifier 
# by Jhoberg Quevedo Ruiz
# Engineer


pkg load symbolic;
pkg load control;

syms S;
syms R1;
syms C1;
syms R2;
syms C2;
syms R4;
syms R3;
%impedacias aplificado1
z1=R1/(S*C1*R1+1)
z2=(S*R2*C2+1)/(S*C2)

%G1(s)=V1/Vi
G1=-z2/z1
G1=simplify(G1)

%imperancias apmplifcador2 
G2=-R4/R3

Gs=G1*G2

%polinomia K+Ki+Kd
Gs=partfrac(Gs)


%R1=1000,R2=10000,C2=1,R3=1000,R4=1000
equ=(C1*R2*R4)/R3+(R4/(C2*R1*R3))+( ((C1*R1*R4)+(C2*R2*R4))/(C2*R1*R3))==0
K=(C1*R2*R4)/R3
Ki=(R4/(C2*R1*R3))
Kd=((C1*R1*R4)+(C2*R2*R4))/(C2*R1*R3)

solve(K==10,C1=10E-6,R2=10000,R4=10000)
